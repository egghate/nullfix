package com.nullfix;

import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value = InGameHud.class, priority = 500)
public class NullFixMixin {

    @Inject(
        method = "setOverlayMessage",
        at = @At("HEAD"),
        cancellable = true
    )
    private void fixNullOverlayMessage(Text message, boolean tinted, CallbackInfo ci) {
        if (message == null) {
            ci.cancel();
        }
    }
}
